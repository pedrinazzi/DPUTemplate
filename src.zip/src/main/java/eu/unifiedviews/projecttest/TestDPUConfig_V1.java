package eu.unifiedviews.projecttest;

/**
 * DPU's configuration class.
 */
public class TestDPUConfig_V1 {

    public TestDPUConfig_V1() {

    }

}
